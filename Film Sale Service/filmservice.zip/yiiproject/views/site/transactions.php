<?php

echo $model;
?>


<div class="col-3">


</div>
