<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model app\models\Payment */
/* @var $form ActiveForm */
?>
<div class="payment" style="color:#012345; background-color: #fff !important; padding: 18px; margin:10px 50px; border-radius: 15px;">

        <p style="text-align: center;">Payment</p>

    <?php $form = ActiveForm::begin(); ?>

        
        <?= $form->field($model, 'card_name') ?>
        <?= $form->field($model, 'card_number') ?>
        <?= $form->field($model, 'month') ?>
        <?= $form->field($model, 'year') ?>
        <?= $form->field($model, 'cvv') ?>
    
        <div class="form-group">
            <?= Html::submitButton('Submit', ['class' => 'btn btn-primary']) ?>
        </div>
    <?php ActiveForm::end(); ?>

</div><!-- payment -->
