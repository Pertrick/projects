<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "todo".
 *
 * @property int $id
 * @property string $name
 * @property string $description
 * @property string $duedate
 */
class Todo extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'todo';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['name','user_id', 'description', 'duedate'], 'required'],
            [['name', 'description'], 'string'],
            [['user_id'], 'default'],
            [['duedate'], 'safe'],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'name' => 'Name',
            'user_id' => 'User_id',
            'description' => 'Description',
            'duedate' => 'Duedate',
        ];
    }
}
