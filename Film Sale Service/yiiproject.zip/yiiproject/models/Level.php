<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "level".
 *
 * @property int $level_id
 * @property string $level_title
 * @property int $dept_id
 */
class Level extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'level';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['level_title', 'dept_id'], 'required'],
            [['level_title'], 'string'],
            [['dept_id'], 'integer'],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'level_id' => 'Level ID',
            'level_title' => 'Level Title',
            'dept_id' => 'Dept ID',
        ];
    }
}
