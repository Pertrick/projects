<?php
namespace app\models;

use Yii;
use yii\base\Model;
use app\models\User;

class SignUpForm extends Model{

	public $username;
	public $email;
	public $password;
	public $password_repeat;
	public $password_reset_token;


	public function rules(){
		return[
			[['username', 'password', 'password_repeat'], 'required'],
			[['email'], 'required'],
			[['username','email'], 'filter', 'filter' => 'trim'],
			[['email'],'email'],
			[['username'], 'string', 'min'=>3, 'max'=>20],
			[['password','password_repeat'], 'string', 'min'=>8, 'max'=>255],
			[['password_repeat'], 'compare', 'compareAttribute' =>'password'],
			[['username'], 'unique','targetClass' => '\app\models\User',
				'message' => 'This username has already been taken.'],
			[['email'], 'unique','targetClass' => '\app\models\User',
				'message' => 'This email has already been taken.']



		];
	}


	public function signUp(){
		if($this->validate()){
			$user = new User();
			$user->username = $this->username;
			$user->email = $this->email;
			$user->password = \Yii::$app->security->generatePasswordHash($this->password); 
			$user->access_token = \Yii::$app->security->generateRandomString();
			$user->authKey  = \Yii::$app->security->generateRandomString();
			
			
			if($user->save()){
				Yii::$app->session->setFlash('success', "Sign up Successful!");
				return true;
			}
			Yii::$app->session->setFlash('danger',"Sign up FAILED!");
			\Yii::error("User was not saved". var_dump($user->errors));

			
		    return false;
	  }

	  return null;

  }



}

