<?php
/* @var $this yii\web\View */
use yii\helpers\Html;
use yii\bootstrap\ActiveForm;
use yii\helpers\ArrayHelper;
use app\models\Faculty;
use app\models\Department;
use app\models\Level;
use app\models\Courses;


$faculties = ArrayHelper::map(Faculty::find()->asArray()->all(), 'id', 'faculty_name');
$departments = ArrayHelper::map(Department::find()->asArray()->all(), 'dept_id', 'dept_name');
$levels = ArrayHelper::map(Level::find()->asArray()->all(), 'level_id', 'level_title');
$courses = ArrayHelper::map(Courses::find()->asArray()->all(), 'course_id', 'course_name');


$this->title = 'Student Portal';
$user =  Yii::$app->user->identity->username;
$this->params['breadcrumbs'][] = $this->title;
?>



<div class="site-login">
	<span style="float:right !important; color:#003300 !important; font-size: 2rem; font-style: italic;;">Welcome, <strong ><?=$user; ?></strong></span>
    <h1><?= Html::encode($this->title) ?></h1>
    <p>Course Registration:</p>

    <hr>

    <?php $form = ActiveForm::begin([
        'id' => 'login-form',
        'layout' => 'horizontal',
        'fieldConfig' => [
            'template' => "{label}\n<div class=\"col-lg-7\">{input}</div>\n<div class=\"col-lg-8\">{error}</div>",
            'labelOptions' => ['class' => 'col-lg-1 control-label'],
        ],
    ]); ?>

        <?= $form-> field($model, 'faculty_id')->dropDownList(
        	$faculties, ['prompt' => '-select your Faculty-', 'onchange' => '$.post("index.php?r=faculty/lists&id='.'"+$(this).val(), function(data){$("select#departments").html(data);
        })'

        ])->label("Faculty") ?>

        <?= $form->field($model, 'dept_name')->dropDownList($departments, ['prompt' => '','id'=> 'departments', 'onchange' => '$.post("index.php?r=faculty/level&id='.'"+$(this).val(), function(data){$("select#level").html(data);
        })' 

        ])->label("Department")?>

         <?= $form->field($model2, 'level_title')->dropDownList($levels, ['prompt' => '','id'=> 'level',
         	'onchange' => '$.post("index.php?r=faculty/course&id='.'"+$(this).val(), function(data){$("#course-list").html(data);
        })' 
        ])->label("Level");?>


        <!--<?= $form->field($model3, 'course_name[]')->checkboxList($courses, ['id'=> 'course',
        'class' => 'btn btn-success', 'data-toggle' => "button",])->label("Select Courses"); ?>

        -->
        <label>Courses:</label>
        <div id="course-list" style=" font-size: 1.7rem !important; color: #003300 !important; margin: 0 auto; width:800px; padding: 2%; font-weight: bold; cursor: pointer; color: #fff;">
        
        </div>


        

        <div class="form-group">
            <div class="col-lg-offset-1 col-lg-11">
                <?= Html::submitButton('Submit', ['class' => 'btn btn-success', 'name' => 'login-button']) ?>
            </div>
        </div>

    <?php ActiveForm::end(); ?>
 
<!--
    <div class="col-lg-offset-1" style="color:#999;">
        You may login with <strong>admin/admin</strong> or <strong>demo/demo</strong>.<br>
        To modify the username/password, please check out the code <code>app\models\User::$users</code>.
    </div>

    -->
</div>
