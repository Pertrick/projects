<?php

namespace app\controllers;

use yii\filters\AccessControl;
use app\models\Faculty;
use app\models\Department;
use app\models\Level;
use app\models\Courses;
use app\models\User;
use app\models\RegCourses;
use Yii;

class FacultyController extends \yii\web\Controller
{


	 public function behaviors()
    {
        return [
        'access' => [
                'class' => AccessControl::className(),
                'only' => ['index', 'logout'],
                'rules' => [

                        //deny all post requests
                    [
                        'allow' => true,
                        'actions' => ['login'],
                        'roles' => ['?'],
                        
                    ],

                    //allow authenticated users
                    [
                        'allow' => true,
                        'actions' => ['index','logout'],
                        'roles' => ['@'],
                    ],
                ],

            ],
        ];
    }

    public function actionIndex()
    {	
    	$model = new Department();
    	$model2 = new Level();
    	$model3 = new Courses();
    	//$model4 = new 
    	
    	$form_action = Yii::$app->request->post();

    	if($form_action){

    		$courses = $form_action["course"];

    		foreach ($courses as $course) {
    			# code...
    			$reg_course = new RegCourses();

    			$reg_course->user_id =  Yii::$app->user->identity->id;
    			$reg_course->course_id = $course;

    			$reg_course->save();


    		}

    	Yii::$app->session->setFlash('success', "Course Registration Successful!");
    	  return $this->goBack();
    	}
    	

    
    	return $this->render('index', [
        'model' => $model, 'model2' => $model2, 'model3' => $model3,
    ]);
    
    }


    public function actionLists($id){

    	$count = Department::find()->where(['faculty_id'=>$id])->count();

    	$dept = Department::find()->where(['faculty_id'=>$id])->orderBy('faculty_id DESC')->all();

    	if(!empty($dept)){

    	if($count >0){
    		foreach ($dept as $deptm) {

    			echo "<option value='" . $deptm->dept_id. "'>" . $deptm->dept_name ."</option";
    			echo "<br>";
    			# code...
    		}
    	}

    		}else{
    			echo "<option>-</option>";
    	}

    }

    	 public function actionLevel($id){

    	$count = Level::find()->where(['dept_id'=>$id])->count();

    	$level = Level::find()->where(['dept_id'=>$id])->orderBy('dept_id DESC')->all();

    	if(!empty($level)){

    	if($count >0){
    		foreach ($level as $levels) {

    			echo "<option value='" . $levels->level_id. "'>" . $levels->level_title ."</option";
    			echo "<br>";
    			# code...
    		}
    	}

    		}else{
    			echo "<option>-</option>";
    	}
    	   
    }

     public function actionCourse($id){

    	$count = Courses::find()->where(['level_id'=>$id])->count();

    	$course = Courses::find()->where(['level_id'=>$id])->orderBy('level_id DESC')->all();

    	if(!empty($course)){

    	if($count >0){
    		
    		foreach ($course as $courses) {
    			echo $courses->course_name;
    			?>
    		<input type='checkbox' name='course[]' value='<?=$courses->course_id ?>' />
    			 <?php
    			echo "<br>";
    			# code...
    		}
    	}

    		}else{
    			echo "<input type='checkbox' />";
    	}
    	   
    }


 
 

}
