<?php

namespace app\controllers;

class DepartmentController extends \yii\web\Controller
{
    public function actionDept()
    {
    	//$model = new Level();

    	if($model->load(Yii::$app->request->post())){
    	   echo $model->user_id;
    		echo "<pre>";
    		print_r($model);
    		echo "</pre>";
    		die();
    	}

        return $this->render('dept', ['model' => $model, ]);
    }

}
